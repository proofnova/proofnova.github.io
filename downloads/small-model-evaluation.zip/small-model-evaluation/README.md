# Reproduce the small-model adapter evaluation

Node.js 22+. Run npm ci, then node run.mjs. The first run downloads the public pinned HuggingFaceTB/SmolLM2-135M-Instruct revision 12fd25f77366fa6b3b4b768ec3050bf629380bac with q4 weights; no API key or paid API is used. After caching, node run.mjs --offline avoids model downloads. The optional evaluation dependency is separate from the dependency-free domain tools.

The fixed protocol contains six new synthetic structured jobs, one per domain, with two predeclared metric fields each and two greedy repeats. Four arms share one model call and a 64-new-token ceiling. In the resource arm the user has already selected a tool and registered the full input. The model copies that allowed tool/input handle and deterministic code computes the result. Controls receive the input payload and compute answers. Input contexts therefore differ. This evaluates a handle-based execution adapter, not autonomous routing, semantic expertise, full-output accuracy or general reasoning improvement. Repeats are stability checks, not independent samples.

Every raw response, prompt, scoring expectation, token estimate and latency is retained in a new results/<timestamp>/ directory. Expected answers are host-side and are not added to prompts. Keep failures; do not select only successful runs. Older long-context pilots failed and are not evidence of improvement. Model loading or writing code is not a successful trial.

The frozen host calculations were actually checked while creating this archive. Downloading this archive does not mean a model run completed on your machine. Read a completed summary and its responses before quoting performance. No real external user impact has been established.
