// Dot paths use the longest remaining literal object key, allowing filenames.
export function getPath(value,path){
  const parts=path.split('.');let current=value;
  while(parts.length){if(current==null)return undefined;const rest=parts.join('.');if(Object.hasOwn(Object(current),rest))return current[rest];current=current[parts.shift()];}return current;
}
export function project(result,expect){return Object.fromEntries(Object.keys(expect).map(path=>[path,getPath(result,path)]));}
