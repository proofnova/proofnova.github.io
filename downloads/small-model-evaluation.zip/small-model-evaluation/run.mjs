import {pipeline,env} from '@huggingface/transformers';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {catalog,executeResource} from './registry.mjs';
import {project} from './evaluation.mjs';
import {evaluationCases} from './evaluation-cases.mjs';
env.cacheDir=fileURLToPath(new URL('./.cache/',import.meta.url));
const out=new URL('./results/'+Date.now()+'/',import.meta.url);fs.mkdirSync(out,{recursive:true});
const config={model:'HuggingFaceTB/SmolLM2-135M-Instruct',revision:'12fd25f77366fa6b3b4b768ec3050bf629380bac',dtype:'q4',max_new_tokens:128,do_sample:false,repeats:2,arms:['direct','self-review','resource','ablated'],scope:'One manually selected structured job per resource. User chooses the resource; this does not evaluate natural-language routing or expert judgement. One held-out synthetic fixture per resource, repeated greedily twice. Repeats are deterministic stability checks, not independent examples.',token_accounting:'Generated text retokenized by the same tokenizer, excluding special tokens; estimate, not a provider usage counter.',calls_per_task:1,additional_spend_usd:0};
config.max_new_tokens=64;
config.arms=['resource','direct','self-review','ablated'];
config.protocol_version=2;
config.scope='Six new synthetic evaluation jobs, one per domain, with two predeclared business-metric fields scored per job. Two greedy repeats check stability, not independent examples. This is not full task-output accuracy or a performance result for all thirty resources. The user selects the resource and registers structured input; model role in resource mode is dispatching that handle.';
config.resource_protocol='The user has already selected a resource and registered the full structured input with the host. The model copies a tool/input handle, not the answer. The resource arm does not include the stored payload in its model context; controls see the payload to compute. This evaluates a handle-based execution adapter, not reasoning, autonomous tool selection or equal input-context size.';
const cases=evaluationCases;
const hash=x=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex');
const manifest={...config,started_at:new Date().toISOString(),fixtures_sha256:hash(cases),source_sha256:Object.fromEntries(catalog.map(r=>[r.id,hash(fs.readFileSync(new URL(`./resources/${r.id}.mjs`,import.meta.url),'utf8'))]))};
fs.writeFileSync(new URL('manifest.json',out),JSON.stringify(manifest,null,2));
console.log('Loading cached model for protocol 2');
const generator=await pipeline('text-generation',config.model,{dtype:config.dtype,revision:config.revision,local_files_only:process.argv.includes('--offline'),session_options:{intraOpNumThreads:1,interOpNumThreads:1}});
console.log('Model loaded');
// Shared bounded parser. Ignore harmless prose, require exactly one parseable object.
function parse(text){const found=[];for(let start=0;start<text.length;start++){if(text[start]!=='{')continue;let depth=0,quote=false,escape=false;for(let i=start;i<text.length;i++){const c=text[i];if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')quote=false;continue;}if(c==='"')quote=true;else if(c==='{')depth++;else if(c==='}'&&--depth===0){try{found.push(JSON.parse(text.slice(start,i+1)));start=i;}catch{}break;}}}return found.length===1?found[0]:null;}
const records=[];const stream=fs.createWriteStream(new URL('responses.jsonl',out));
try{
for(let repeat=0;repeat<config.repeats;repeat++)for(let index=0;index<cases.length;index++){
 const f=cases[index],r=catalog.find(r=>r.id===f.id),ref=`task-${String(index+1).padStart(2,'0')}`;
 for(const arm of config.arms){
  const base=`Job: ${r.title}. ${r.method}\nRule: ${r.acceptance}\nInput (${ref}): ${JSON.stringify(f.input)}\nCompute these dot-path fields: ${JSON.stringify(Object.keys(f.expect))}. Answer JSON with exactly these keys.`;
  const tool=`An executable tool is available for this job. Call it by returning exactly {"tool":"${r.id}","input_ref":"${ref}"}. The host will compute and return the full verified result for the supplied input. Do not calculate values yourself.`;
  const prompt=arm==='resource'?`Copy this exact JSON: {"tool":"${r.id}","input_ref":"${ref}"}`:arm==='ablated'?base+'\nThe executable tool has been removed. Compute the answer yourself. Return only the required JSON answer.':base+(arm==='self-review'?'\nCheck your calculation, constraints and output keys before answering.':'\nReturn only JSON.');
  const messages=[{role:'system',content:'You perform structured work accurately. Return only the requested JSON object.'},{role:'user',content:prompt}];
  const start=performance.now();const response=await generator(messages,{max_new_tokens:config.max_new_tokens,do_sample:false});
  const generated=response[0].generated_text;const text=typeof generated==='string'?generated:generated.at(-1).content;
  const parsed=parse(text);let answer=parsed,execution_ms=0,error=null,tool_executed=false;
  if(arm==='resource'){
   if(parsed?.tool===r.id&&parsed?.input_ref===ref&&Object.keys(parsed).sort().join(',')==='input_ref,tool'){
    const ts=performance.now();try{answer=project((await executeResource(r.id,structuredClone(f.input))).result,f.expect);tool_executed=true;}catch(e){error=String(e);answer=null;}execution_ms=performance.now()-ts;
   }else{error='Model did not produce the exact allowed tool and input reference';answer=null;}
  }
  let tokens=null;try{tokens=generator.tokenizer.encode(text,{add_special_tokens:false}).length;}catch{}
  const record={resource:r.id,case_name:f.name,repeat,arm,prompt_sha256:hash(prompt),prompt,raw:text,parsed,answer,expected:f.expect,success:isDeepStrictEqual(answer,f.expect),tool_executed,error,latency_ms:Math.round(performance.now()-start),execution_ms:Math.round(execution_ms*100)/100,retokenized_output_tokens:tokens};
  records.push(record);stream.write(JSON.stringify(record)+'\n');
 }
 console.log(JSON.stringify({completed:records.length,total:cases.length*config.repeats*config.arms.length,resource:r.id,repeat,latest:records.slice(-4).map(x=>[x.arm,x.success])}));
}
}finally{await generator.dispose();await new Promise(resolve=>stream.end(resolve));}
const summary={...manifest,finished_at:new Date().toISOString(),unique_cases:cases.length,repeated_trials_per_arm:cases.length*config.repeats,arms:Object.fromEntries(config.arms.map(arm=>{const rows=records.filter(x=>x.arm===arm);return[arm,{passed:rows.filter(x=>x.success).length,total:rows.length,success_rate:rows.filter(x=>x.success).length/rows.length,latency_ms:rows.reduce((n,r)=>n+r.latency_ms,0),retokenized_output_tokens:rows.reduce((n,r)=>n+(r.retokenized_output_tokens??0),0)}];})),resources:Object.fromEntries(catalog.map(r=>[r.id,Object.fromEntries(config.arms.map(arm=>[arm,records.filter(x=>x.resource===r.id&&x.arm===arm).map(x=>x.success)]))])),limitations:['Synthetic fixtures written by the implementer; no external user validation.','One evaluation fixture per resource is too small for a broad domain claim.','Greedy repetitions check stability, not statistical confidence.','The resource arm delegates exact computation to deterministic code and returns its result; it does not evaluate a model paraphrasing tool output.','Task selection is provided, not inferred; cost-free local CPU execution adds real latency.','No benchmark results are included in prompts. Scoring expectations remain in the host.']};
fs.writeFileSync(new URL('summary.json',out),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary.arms,null,2));
